# DMI Predictor Hub
This is a mockup project for frontend + backend.
